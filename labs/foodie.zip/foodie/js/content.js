var chilePies = {
	"name": "Chile Pies",
	"street_address": "314 Church St.",
	"phone": "(415) 431-9411"
};

var blackbird = {
	"name": "Blackbird",
	"street_address": "2124 Market St.",
	"phone": "(415) 503-0630"
};

var ikes = {
	"name": "Ike's Place",
	"street_address": "3489 16th St.",
	"phone": "(415) 553-6888"
};


var json = {
	"objects": [
		chilePies,
		blackbird,
		ikes
	]
};

var json = {
	"objects": [ chilePies, blackbird, ikes ]
};


